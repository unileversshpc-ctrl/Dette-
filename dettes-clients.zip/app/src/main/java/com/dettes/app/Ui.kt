package com.dettes.app

import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val RedColor = Color(0xFFC62828)
private val GreenColor = Color(0xFF2E7D32)

fun money(value: Double): String {
    val f = NumberFormat.getNumberInstance(Locale.US)
    f.maximumFractionDigits = 2
    return f.format(value) + " د.ج"
}

fun fmtDate(time: Long): String =
    SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(Date(time))

@Composable
fun App(vm: MainViewModel = viewModel()) {
    var detailId by rememberSaveable { mutableStateOf<Long?>(null) }
    BackHandler(enabled = detailId != null) { detailId = null }
    val id = detailId
    if (id == null) {
        HomeScreen(vm) { detailId = it }
    } else {
        DetailScreen(vm, id) { detailId = null }
    }
}

// ───────────────────────── الشاشة الرئيسية ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel, onOpen: (Long) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (tab == 0) "ديون العملاء" else "سجل التحصيل") }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Person, contentDescription = null) },
                    label = { Text("العملاء") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Check, contentDescription = null) },
                    label = { Text("سجل التحصيل") }
                )
            }
        },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة عميل")
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) CustomersTab(vm, onOpen) else CollectionsTab(vm, onOpen)
        }
    }

    if (showAdd) {
        AddCustomerDialog(
            onDismiss = { showAdd = false },
            onSave = { name, phone ->
                vm.addCustomer(name, phone)
                showAdd = false
            }
        )
    }
}

@Composable
fun CustomersTab(vm: MainViewModel, onOpen: (Long) -> Unit) {
    val customers by vm.customers.collectAsState()
    var query by remember { mutableStateOf("") }
    val q = query.trim()
    val shown = customers.filter {
        q.isEmpty() || it.name.contains(q, ignoreCase = true) || it.phone.contains(q)
    }
    val total = customers.sumOf { if (it.balance > 0) it.balance else 0.0 }
    val debtors = customers.count { it.balance > 0 }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Card(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("إجمالي الديون المتبقية", fontSize = 14.sp)
                Text(money(total), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = RedColor)
                Text("$debtors عميل مدين من أصل ${customers.size}", fontSize = 12.sp)
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            placeholder = { Text("بحث بالاسم أو الهاتف") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true
        )

        if (shown.isEmpty()) {
            Text(
                if (customers.isEmpty()) "لا يوجد عملاء بعد. اضغط + لإضافة عميل." else "لا توجد نتائج.",
                modifier = Modifier.padding(24.dp)
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 88.dp)
        ) {
            items(shown, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(c.id) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                            if (c.phone.isNotBlank()) Text(c.phone, fontSize = 13.sp)
                        }
                        Text(
                            money(c.balance),
                            fontWeight = FontWeight.Bold,
                            color = if (c.balance > 0) RedColor else GreenColor
                        )
                    }
                }
            }
        }
    }
}

// ───────────────────────── سجل التحصيل ─────────────────────────

@Composable
fun CollectionsTab(vm: MainViewModel, onOpen: (Long) -> Unit) {
    val all by vm.collections.collectAsState()
    var range by rememberSaveable { mutableIntStateOf(0) } // 0 اليوم، 1 هذا الشهر، 2 الكل
    val start = remember(range) {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (range == 1) c.set(Calendar.DAY_OF_MONTH, 1)
        if (range == 2) 0L else c.timeInMillis
    }
    val shown = all.filter { it.date >= start }
    val total = shown.sumOf { it.amount }
    val labels = listOf("اليوم", "هذا الشهر", "الكل")

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            labels.forEachIndexed { i, label ->
                FilterChip(
                    selected = range == i,
                    onClick = { range = i },
                    label = { Text(label) }
                )
            }
        }

        Card(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("إجمالي المحصَّل", fontSize = 14.sp)
                Text(money(total), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = GreenColor)
                Text("${shown.size} عملية تحصيل", fontSize = 12.sp)
            }
        }

        if (shown.isEmpty()) {
            Text("لا توجد عمليات تحصيل في هذه الفترة.", modifier = Modifier.padding(24.dp))
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(shown, key = { it.id }) { item ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(item.customerId) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.customerName, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            if (item.note.isNotBlank()) Text(item.note, fontSize = 13.sp)
                            Text(fmtDate(item.date), fontSize = 12.sp)
                        }
                        Text(money(item.amount), fontWeight = FontWeight.Bold, color = GreenColor)
                    }
                }
            }
        }
    }
}

// ───────────────────────── تفاصيل العميل ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: MainViewModel, id: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val customer by remember(id) { vm.customer(id) }.collectAsState(initial = null)
    val txns by remember(id) { vm.transactions(id) }.collectAsState(initial = emptyList())

    var dialogType by remember { mutableStateOf<String?>(null) }
    var confirmDeleteCustomer by remember { mutableStateOf(false) }
    var txnToDelete by remember { mutableStateOf<Txn?>(null) }

    val c = customer
    val balance = txns.sumOf { if (it.type == TYPE_DEBT) it.amount else -it.amount }
    val collected = txns.filter { it.type == TYPE_PAYMENT }.sumOf { it.amount }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(c?.name ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { if (c != null) shareStatement(ctx, c, txns, balance) }) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة كشف الحساب")
                    }
                    IconButton(onClick = { confirmDeleteCustomer = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف العميل")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
            Card(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp)) {
                    if (c != null && c.phone.isNotBlank()) Text("الهاتف: ${c.phone}", fontSize = 13.sp)
                    Text("المبلغ المتبقي", fontSize = 14.sp)
                    Text(
                        money(balance),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (balance > 0) RedColor else GreenColor
                    )
                    Text("إجمالي ما تم تحصيله: ${money(collected)}", fontSize = 13.sp)
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { dialogType = TYPE_DEBT },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RedColor)
                ) { Text("دين جديد") }
                Button(
                    onClick = { dialogType = TYPE_PAYMENT },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenColor)
                ) { Text("تحصيل دفعة") }
            }

            Text("سجل العمليات", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))

            if (txns.isEmpty()) Text("لا توجد عمليات بعد.")

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(txns, key = { it.id }) { t ->
                    val isPayment = t.type == TYPE_PAYMENT
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (isPayment) "تحصيل" else "دين",
                                    fontWeight = FontWeight.Medium,
                                    color = if (isPayment) GreenColor else RedColor
                                )
                                if (t.note.isNotBlank()) Text(t.note, fontSize = 13.sp)
                                Text(fmtDate(t.date), fontSize = 12.sp)
                            }
                            Text(
                                (if (isPayment) "- " else "+ ") + money(t.amount),
                                fontWeight = FontWeight.Bold,
                                color = if (isPayment) GreenColor else RedColor
                            )
                            IconButton(onClick = { txnToDelete = t }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف العملية")
                            }
                        }
                    }
                }
            }
        }
    }

    dialogType?.let { type ->
        AmountDialog(
            isPayment = type == TYPE_PAYMENT,
            onDismiss = { dialogType = null },
            onSave = { amount, note ->
                vm.addTxn(id, type, amount, note)
                dialogType = null
            }
        )
    }

    if (confirmDeleteCustomer && c != null) {
        ConfirmDialog(
            message = "سيتم حذف العميل «${c.name}» وكل عملياته نهائياً. متأكد؟",
            onDismiss = { confirmDeleteCustomer = false },
            onConfirm = {
                confirmDeleteCustomer = false
                vm.deleteCustomer(c)
                onBack()
            }
        )
    }

    txnToDelete?.let { t ->
        ConfirmDialog(
            message = "حذف هذه العملية (${money(t.amount)})؟",
            onDismiss = { txnToDelete = null },
            onConfirm = {
                vm.deleteTxn(t)
                txnToDelete = null
            }
        )
    }
}

// ───────────────────────── نوافذ الحوار ─────────────────────────

@Composable
fun AddCustomerDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("عميل جديد") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("الاسم") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("الهاتف (اختياري)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onSave(name, phone) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun AmountDialog(isPayment: Boolean, onDismiss: () -> Unit, onSave: (Double, String) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val value = amount.replace(',', '.').toDoubleOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isPayment) "تسجيل تحصيل" else "تسجيل دين جديد") },
        text = {
            Column {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("المبلغ (د.ج)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة (اختياري)") }
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = value != null && value > 0,
                onClick = { if (value != null) onSave(value, note) }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun ConfirmDialog(message: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text("حذف") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ───────────────────────── مشاركة كشف الحساب ─────────────────────────

fun shareStatement(ctx: Context, c: Customer, txns: List<Txn>, balance: Double) {
    val sb = StringBuilder()
    sb.append("كشف حساب: ").append(c.name).append('\n')
    sb.append("المبلغ المتبقي: ").append(money(balance)).append("\n\n")
    txns.sortedBy { it.date }.forEach { t ->
        val kind = if (t.type == TYPE_PAYMENT) "تحصيل" else "دين"
        sb.append(fmtDate(t.date)).append(" | ").append(kind).append(" | ").append(money(t.amount))
        if (t.note.isNotBlank()) sb.append(" | ").append(t.note)
        sb.append('\n')
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, sb.toString())
    }
    ctx.startActivity(Intent.createChooser(send, "مشاركة كشف الحساب"))
}
