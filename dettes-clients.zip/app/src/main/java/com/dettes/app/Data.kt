package com.dettes.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

const val TYPE_DEBT = "DEBT"
const val TYPE_PAYMENT = "PAYMENT"

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("customerId")]
)
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val type: String,
    val amount: Double,
    val note: String = "",
    val date: Long = System.currentTimeMillis()
)

data class CustomerBalance(
    val id: Long,
    val name: String,
    val phone: String,
    val balance: Double
)

data class CollectionItem(
    val id: Long,
    val customerId: Long,
    val customerName: String,
    val amount: Double,
    val note: String,
    val date: Long
)

@Dao
interface DebtDao {
    @Query(
        """
        SELECT c.id AS id, c.name AS name, c.phone AS phone,
               COALESCE(SUM(CASE WHEN t.type = 'DEBT' THEN t.amount
                                 WHEN t.type = 'PAYMENT' THEN -t.amount
                                 ELSE 0 END), 0) AS balance
        FROM customers c
        LEFT JOIN transactions t ON t.customerId = c.id
        GROUP BY c.id
        ORDER BY c.name COLLATE NOCASE
        """
    )
    fun customersWithBalance(): Flow<List<CustomerBalance>>

    @Query("SELECT * FROM customers WHERE id = :id")
    fun customer(id: Long): Flow<Customer?>

    @Query("SELECT * FROM transactions WHERE customerId = :id ORDER BY date DESC, id DESC")
    fun transactionsOf(id: Long): Flow<List<Txn>>

    @Query(
        """
        SELECT t.id AS id, t.customerId AS customerId, c.name AS customerName,
               t.amount AS amount, t.note AS note, t.date AS date
        FROM transactions t
        JOIN customers c ON c.id = t.customerId
        WHERE t.type = 'PAYMENT'
        ORDER BY t.date DESC, t.id DESC
        """
    )
    fun collections(): Flow<List<CollectionItem>>

    @Insert
    suspend fun insertCustomer(customer: Customer): Long

    @Update
    suspend fun updateCustomer(customer: Customer)

    @Delete
    suspend fun deleteCustomer(customer: Customer)

    @Insert
    suspend fun insertTxn(txn: Txn)

    @Delete
    suspend fun deleteTxn(txn: Txn)
}

@Database(entities = [Customer::class, Txn::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): DebtDao

    companion object {
        @Volatile
        private var instance: AppDb? = null

        fun get(context: Context): AppDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDb::class.java,
                    "dettes.db"
                ).build().also { instance = it }
            }
    }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val customers = dao.customersWithBalance()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val collections = dao.collections()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun customer(id: Long): Flow<Customer?> = dao.customer(id)

    fun transactions(id: Long): Flow<List<Txn>> = dao.transactionsOf(id)

    fun addCustomer(name: String, phone: String) {
        viewModelScope.launch {
            dao.insertCustomer(Customer(name = name.trim(), phone = phone.trim()))
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch { dao.deleteCustomer(customer) }
    }

    fun addTxn(customerId: Long, type: String, amount: Double, note: String) {
        viewModelScope.launch {
            dao.insertTxn(Txn(customerId = customerId, type = type, amount = amount, note = note.trim()))
        }
    }

    fun deleteTxn(txn: Txn) {
        viewModelScope.launch { dao.deleteTxn(txn) }
    }
}
